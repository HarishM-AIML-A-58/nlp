import math
from collections import Counter

docs = [
    'the cat sat on the mat',
    'the dog lay on the rug',
    'the cat and the dog play'
]

def tf(doc):
    words = doc.split()
    c = Counter(words)
    return {w: c[w]/len(words) for w in c}

def idf(docs):
    N = len(docs)
    all_words = set(w for d in docs for w in d.split())
    scores = {}
    for w in all_words:
        df = sum(1 for d in docs if w in d.split())
        scores[w] = math.log(N / df)
    return scores

idf_scores = idf(docs)
tfidf = [{w: tf(d)[w]*idf_scores[w] for w in tf(d)} for d in docs]

print('TF-IDF for doc1:')
for w, s in sorted(tfidf[0].items(), key=lambda x:-x[1])[:5]:
    print(f'  {w}: {s:.4f}')

def cosine(v1, v2):
    keys  = set(v1) | set(v2)
    dot   = sum(v1.get(k,0) * v2.get(k,0) for k in keys)
    mag1  = math.sqrt(sum(x**2 for x in v1.values()))
    mag2  = math.sqrt(sum(x**2 for x in v2.values()))
    return dot / (mag1 * mag2) if mag1 and mag2 else 0

print(f'Cosine(doc1, doc2): {cosine(tfidf[0], tfidf[1]):.4f}')
print(f'Cosine(doc1, doc3): {cosine(tfidf[0], tfidf[2]):.4f}')

all_words = []
for d in docs: all_words.extend(d.split())
N2 = len(all_words)
wf = Counter(all_words)
pairs = Counter(zip(all_words, all_words[1:]))

def pmi(x, y):
    pxy = pairs.get((x,y), 0) / N2
    px  = wf[x] / N2
    py  = wf[y] / N2
    if pxy == 0: return float('-inf')
    return math.log2(pxy / (px * py))

print(f'PMI(cat, sat):  {pmi("cat","sat"):.4f}')
print(f'PMI(the, cat):  {pmi("the","cat"):.4f}')
