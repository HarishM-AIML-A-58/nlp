SENSE_DICT = {
    'bank': {
        'financial': 'financial institution money deposit loan savings account credit',
        'river':     'river stream water edge shore flow land soil ground',
    },
    'bat': {
        'animal':   'flying mammal night cave wing echolocation creature',
        'cricket':  'cricket sport player wood hit ball game wicket',
    },
    'plant': {
        'biology':  'tree flower leaf root grow soil garden nature organism',
        'factory':  'factory building manufacturing industrial production workers',
    }
}

def lesk(word, context_sentence):
    if word not in SENSE_DICT:
        return 'Unknown word'

    context_words = set(context_sentence.lower().split())
    best_sense    = None
    best_overlap  = -1

    for sense, definition in SENSE_DICT[word].items():
        def_words = set(definition.split())
        overlap   = len(context_words & def_words)
        if overlap > best_overlap:
            best_overlap = overlap
            best_sense   = sense

    defn = SENSE_DICT[word][best_sense]
    return best_sense, best_overlap, defn

tests = [
    ('bank',  'I deposited money in the bank yesterday'),
    ('bank',  'They sat on the bank of the river'),
    ('bat',   'The bat flew out of the cave at night'),
    ('bat',   'He hit the ball with a bat in cricket'),
    ('plant', 'The factory plant produced cars all day'),
    ('plant', 'The plant grew well in the garden soil'),
]
for word, ctx in tests:
    sense, overlap, defn = lesk(word, ctx)
    print(f'Word: "{word}" | Context: "{ctx[:40]}..."')
    print(f'  -> Sense: {sense} (overlap={overlap})')
    print(f'  -> Definition: {defn[:50]}')
    print()
