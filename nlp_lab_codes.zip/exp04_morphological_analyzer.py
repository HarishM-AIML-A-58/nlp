PREFIXES = ['un', 'pre', 're', 'dis', 'mis', 'over', 'under', 'non', 'anti']
SUFFIXES = ['ing', 'ed', 'er', 'est', 'ly', 'tion', 'ness', 'ment', 'ful', 'less']

def analyze(word):
    prefix = ''
    suffix = ''
    root   = word.lower()

    for p in sorted(PREFIXES, key=len, reverse=True):
        if root.startswith(p):
            prefix = p
            root = root[len(p):]
            break

    for s in sorted(SUFFIXES, key=len, reverse=True):
        if root.endswith(s) and len(root) > len(s):
            suffix = s
            root = root[:-len(s)]
            break

    return prefix, root, suffix

words = ['unhappiness', 'preprocessing', 'rethinking', 'displacement', 'lovely']
print(f'{"Word":<18} {"Prefix":<10} {"Root":<12} {"Suffix":<10}')
print('-' * 50)
for w in words:
    p, r, s = analyze(w)
    print(f'{w:<18} {p:<10} {r:<12} {s:<10}')
