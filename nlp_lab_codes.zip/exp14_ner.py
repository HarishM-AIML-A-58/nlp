import re

PERSONS  = {'john', 'alice', 'bob', 'mary', 'david', 'emma'}
ORGS     = {'google', 'apple', 'microsoft', 'nasa', 'mit', 'amazon'}
LOCS     = {'paris', 'london', 'india', 'chennai', 'new york', 'tokyo'}

PER_TITLES = re.compile(r'\b(Mr|Mrs|Dr|Prof|Ms)\.?\s+([A-Z][a-z]+)', re.I)

def ner_tag(text):
    entities = []
    words    = text.split()

    for m in PER_TITLES.finditer(text):
        entities.append((m.group(), 'PER'))

    for i, w in enumerate(words):
        clean = w.strip('.,!?').lower()
        if i < len(words)-1:
            bigram = (w + ' ' + words[i+1]).lower().strip('.,!?')
            if bigram in LOCS:
                entities.append((w+' '+words[i+1], 'LOC'))
                continue
        if clean in PERSONS:  entities.append((w, 'PER'))
        elif clean in ORGS:   entities.append((w, 'ORG'))
        elif clean in LOCS:   entities.append((w, 'LOC'))

    return entities

sentences = [
    'Dr. John works at Google in London.',
    'Alice and Bob visited Paris and Tokyo.',
    'NASA launched a satellite from Chennai.',
]
for s in sentences:
    print(f'Text: {s}')
    print(f'Entities: {ner_tag(s)}\n')
