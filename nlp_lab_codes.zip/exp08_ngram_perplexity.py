from collections import Counter
import math

corpus = 'the cat sat on the mat the cat is fat the mat is flat'
words  = corpus.split()
N      = len(words)

unigram = Counter(words)
bigram  = Counter(zip(words, words[1:]))
trigram = Counter(zip(words, words[1:], words[2:]))

V = len(unigram)

def p_uni(w):
    return (unigram[w] + 1) / (N + V)

def p_bi(w, prev):
    return (bigram[(prev, w)] + 1) / (unigram[prev] + V)

def p_tri(w, p1, p2):
    return (trigram[(p1, p2, w)] + 1) / (bigram[(p1, p2)] + V)

def perplexity(log_probs, n):
    return math.exp(-sum(log_probs) / n)

test = 'the cat is fat'.split()

uni_lp  = [math.log(p_uni(w)) for w in test]
bi_lp   = [math.log(p_bi(test[i], test[i-1])) for i in range(1, len(test))]
tri_lp  = [math.log(p_tri(test[i], test[i-2], test[i-1])) for i in range(2, len(test))]

print(f'Unigram  Perplexity: {perplexity(uni_lp,  len(uni_lp)):.4f}')
print(f'Bigram   Perplexity: {perplexity(bi_lp,   len(bi_lp)):.4f}')
print(f'Trigram  Perplexity: {perplexity(tri_lp,  len(tri_lp)):.4f}')
