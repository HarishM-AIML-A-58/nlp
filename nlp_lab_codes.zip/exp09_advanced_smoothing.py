from collections import Counter
import math

corpus = 'the cat sat on the mat the cat is fat'
words  = corpus.split()
N      = len(words)
uni    = Counter(words)
bi     = Counter(zip(words, words[1:]))
tri    = Counter(zip(words, words[1:], words[2:]))
V      = len(uni)

def p_addk(word, k=0.5):
    return (uni[word] + k) / (N + k * V)

L1, L2, L3 = 0.1, 0.3, 0.6

def p_uni(w):       return (uni[w] + 1) / (N + V)
def p_bi(w, p):     return (bi[(p,w)] + 1) / (uni[p] + V)
def p_tri(w,p1,p2): return (tri[(p1,p2,w)]+1) / (bi[(p1,p2)] + V)

def p_interpolated(w, prev1=None, prev2=None):
    pu = p_uni(w)
    pb = p_bi(w, prev1)  if prev1 else pu
    pt = p_tri(w, prev2, prev1) if prev2 else pb
    return L1 * pu + L2 * pb + L3 * pt

test = [('cat', None, None), ('dog', None, None), ('sat', 'cat', 'the')]
print(f'{"Word":<8}{"Add-k":>10}{"Interpolated":>16}')
print('-' * 36)
for w, p1, p2 in test:
    ak = p_addk(w)
    ip = p_interpolated(w, p1, p2)
    print(f'{w:<8}{ak:>10.4f}{ip:>16.4f}')
