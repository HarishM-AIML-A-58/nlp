from collections import defaultdict, Counter

train = [
    [('The','DT'),('cat','NN'),('runs','VB')],
    [('A','DT'),('dog','NN'),('barks','VB')],
    [('The','DT'),('bird','NN'),('sings','VB')],
    [('Big','JJ'),('dogs','NN'),('run','VB')],
    [('Small','JJ'),('cats','NN'),('sleep','VB')]
]

trans = defaultdict(Counter)
emiss = defaultdict(Counter)
init  = Counter()

for sent in train:
    init[sent[0][1]] += 1
    for i,(w,t) in enumerate(sent):
        emiss[t][w.lower()] += 1
        if i > 0: trans[sent[i-1][1]][t] += 1

tags = list(emiss.keys())

def p_init(t):    return (init[t]+1) / (len(train) + len(tags))
def p_trans(p,t): return (trans[p][t]+1)/(sum(trans[p].values())+len(tags))
def p_emiss(t,w): return (emiss[t][w.lower()]+1)/(sum(emiss[t].values())+1000)

def tag_sentence(sentence):
    words = sentence.split()
    T     = len(words)
    vit   = [{} for _ in range(T)]
    back  = [{} for _ in range(T)]
    for t in tags:
        vit[0][t] = p_init(t) * p_emiss(t, words[0])
    for i in range(1, T):
        for t in tags:
            best = max(tags, key=lambda p: vit[i-1][p]*p_trans(p,t))
            vit[i][t]  = vit[i-1][best]*p_trans(best,t)*p_emiss(t,words[i])
            back[i][t] = best
    seq = [max(tags, key=lambda t: vit[T-1][t])]
    for i in range(T-1,0,-1):
        seq.insert(0, back[i][seq[0]])
    return list(zip(words, seq))

print(tag_sentence('The dog runs'))
print(tag_sentence('Big cats sleep'))
