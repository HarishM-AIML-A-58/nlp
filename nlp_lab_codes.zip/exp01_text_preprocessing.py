import nltk
import re
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.tokenize import word_tokenize

nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('brown', quiet=True)

from nltk.corpus import brown

raw_words = brown.words()[:50]
text = ' '.join(raw_words)
print('Original:', text)

text_lower = text.lower()
text_clean = re.sub(r'[^a-z\s]', '', text_lower)
print('Cleaned:', text_clean)

tokens = word_tokenize(text_clean)
print('Tokens:', tokens)

stop_words = set(stopwords.words('english'))
filtered = [w for w in tokens if w not in stop_words]
print('After Stopword Removal:', filtered)

stemmer = PorterStemmer()
stemmed = [stemmer.stem(w) for w in filtered]
print('Stemmed:', stemmed)

lemmatizer = WordNetLemmatizer()
lemmatized = [lemmatizer.lemmatize(w) for w in filtered]
print('Lemmatized:', lemmatized)
