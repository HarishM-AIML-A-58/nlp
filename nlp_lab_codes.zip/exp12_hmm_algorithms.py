states = ['N', 'V']
obs    = ['the', 'dog', 'runs']

pi = {'N': 0.6, 'V': 0.4}

A = {'N': {'N': 0.4, 'V': 0.6}, 'V': {'N': 0.7, 'V': 0.3}}

B = {'N': {'the':0.4,'dog':0.5,'runs':0.1},
     'V': {'the':0.1,'dog':0.1,'runs':0.8}}

def forward(obs):
    T   = len(obs)
    fwd = [{s: 0 for s in states} for _ in range(T)]
    fwd[0] = {s: pi[s]*B[s][obs[0]] for s in states}
    for t in range(1, T):
        for s in states:
            fwd[t][s] = sum(fwd[t-1][p]*A[p][s]*B[s][obs[t]]
                           for p in states)
    return fwd

def viterbi(obs):
    T      = len(obs)
    vit    = [{} for _ in range(T)]
    backp  = [{} for _ in range(T)]
    vit[0] = {s: pi[s]*B[s][obs[0]] for s in states}
    for t in range(1, T):
        for s in states:
            best = max(states, key=lambda p: vit[t-1][p]*A[p][s])
            vit[t][s]   = vit[t-1][best]*A[best][s]*B[s][obs[t]]
            backp[t][s] = best
    seq  = [max(states, key=lambda s: vit[T-1][s])]
    for t in range(T-1, 0, -1):
        seq.insert(0, backp[t][seq[0]])
    return seq

fwd = forward(obs)
print('Forward probs:', [{s:round(fwd[t][s],4) for s in states} for t in range(len(obs))])
print('P(obs):', round(sum(fwd[-1].values()), 6))
print('Viterbi path:', list(zip(obs, viterbi(obs))))
