SR_GRAMMAR = {
    ('DT', 'NN'): 'NP',
    ('NP', 'VP'): 'S',
    ('VB', 'NP'): 'VP',
    ('VB',):      'VP',
}
LEXICON = {'the':'DT', 'a':'DT', 'cat':'NN', 'dog':'NN',
           'sees':'VB', 'chases':'VB'}

def shift_reduce(sentence):
    tokens = sentence.lower().split()
    stack  = []
    buf    = [LEXICON.get(w, w) for w in tokens]
    print(f'Input tags: {buf}')
    while buf or len(stack) > 1:
        reduced = False
        for ln in (3, 2, 1):
            if len(stack) >= ln:
                top  = tuple(stack[-ln:])
                if top in SR_GRAMMAR:
                    stack = stack[:-ln] + [SR_GRAMMAR[top]]
                    print(f'  REDUCE {top} -> {SR_GRAMMAR[top]} | Stack: {stack}')
                    reduced = True
                    break
        if not reduced:
            if buf:
                stack.append(buf.pop(0))
                print(f'  SHIFT -> Stack: {stack}')
            else: break
    print(f'Result: {stack}')
    return stack == ['S']

print('--- Shift-Reduce ---')
shift_reduce('the cat sees a dog')

print('\n--- CYK Algorithm ---')

CYK_GRAM = {
    'NP': [('DT','NN')],
    'VP': [('VB','NP')],
    'S':  [('NP','VP')],
    'DT': ['the','a'],
    'NN': ['cat','dog'],
    'VB': ['sees','chases']
}

def cyk(sentence):
    words = sentence.lower().split()
    n     = len(words)
    dp    = [[set() for _ in range(n)] for _ in range(n)]
    for i, w in enumerate(words):
        for sym, vals in CYK_GRAM.items():
            if w in vals: dp[i][i].add(sym)
    for length in range(2, n+1):
        for i in range(n-length+1):
            j = i + length - 1
            for k in range(i, j):
                for sym,(l,r) in [(s,rule) for s,rules in CYK_GRAM.items()
                                  for rule in rules if isinstance(rule,tuple)]:
                    if l in dp[i][k] and r in dp[k+1][j]:
                        dp[i][j].add(sym)
    print(f'Parseable: {"S" in dp[0][n-1]}')
    return 'S' in dp[0][n-1]

cyk('the cat sees a dog')
cyk('dog the sees')
