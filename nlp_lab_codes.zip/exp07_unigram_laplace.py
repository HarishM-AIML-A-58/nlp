from collections import Counter
import math

corpus = ['the cat sat on the mat',
          'the cat is fat',
          'the mat is flat']

all_words = []
for sent in corpus:
    all_words.extend(sent.split())

freq  = Counter(all_words)
N     = len(all_words)
V     = len(freq)

def p_unigram(word):
    return freq.get(word, 0) / N

def p_laplace(word):
    return (freq.get(word, 0) + 1) / (N + V)

test_words = ['cat', 'mat', 'dog']
print(f'{"Word":<10} {"Unigram":>12} {"Laplace":>12}')
print('-' * 36)
for w in test_words:
    print(f'{w:<10} {p_unigram(w):>12.4f} {p_laplace(w):>12.4f}')

sentence = 'the cat sat'
log_prob = sum(math.log(p_laplace(w)) for w in sentence.split())
print(f'\nLog-prob of "{sentence}": {log_prob:.4f}')
