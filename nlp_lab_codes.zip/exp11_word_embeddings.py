import math
from collections import defaultdict, Counter

corpus = [
    'the king rules the kingdom',
    'the queen rules the land',
    'the prince is the son of king',
    'the princess is the daughter of queen',
    'man and woman are people',
    'king and queen are royals'
]

WINDOW = 2

cooccur = defaultdict(Counter)
for sent in corpus:
    words = sent.split()
    for i, word in enumerate(words):
        for j in range(max(0,i-WINDOW), min(len(words),i+WINDOW+1)):
            if i != j:
                cooccur[word][words[j]] += 1

def cosine(w1, w2):
    v1, v2 = cooccur[w1], cooccur[w2]
    keys   = set(v1) | set(v2)
    dot    = sum(v1.get(k,0)*v2.get(k,0) for k in keys)
    m1     = math.sqrt(sum(x**2 for x in v1.values()))
    m2     = math.sqrt(sum(x**2 for x in v2.values()))
    return dot/(m1*m2) if m1 and m2 else 0

def most_similar(word, top=3):
    vocab = [w for w in cooccur if w != word]
    sims  = [(w, cosine(word, w)) for w in vocab]
    return sorted(sims, key=lambda x:-x[1])[:top]

for w in ['king', 'queen', 'man']:
    sim = most_similar(w)
    print(f'{w}: {sim}')
