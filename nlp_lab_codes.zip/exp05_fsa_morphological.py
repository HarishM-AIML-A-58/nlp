PREFIXES = ['un', 're', 'pre', 'dis', 'mis']
SUFFIXES = ['ing', 'ed', 'tion', 'ness', 'ment', 'ly', 'er']
ROOTS    = ['happy', 'play', 'kind', 'place', 'think',
            'read', 'write', 'do', 'move', 'call']

def fsa_analyze(word):
    state  = 'START'
    w      = word.lower()
    result = {'prefix':'', 'root':'', 'suffix':'', 'states':[]}

    result['states'].append(state)

    for p in sorted(PREFIXES, key=len, reverse=True):
        if w.startswith(p):
            result['prefix'] = p
            w = w[len(p):]
            state = 'PREFIX'
            result['states'].append(state)
            break

    for r in sorted(ROOTS, key=len, reverse=True):
        if w.startswith(r):
            result['root'] = r
            w = w[len(r):]
            state = 'ROOT'
            result['states'].append(state)
            break

    for s in sorted(SUFFIXES, key=len, reverse=True):
        if w == s:
            result['suffix'] = s
            state = 'SUFFIX'
            result['states'].append(state)
            break

    if result['root']:
        state = 'ACCEPT'
    else:
        state = 'REJECT'
    result['states'].append(state)
    return result

for word in ['unhappy', 'replaying', 'kindness', 'displacement', 'xyz']:
    r = fsa_analyze(word)
    print(f'{word}: {" -> ".join(r["states"])}')
    print(f'  Prefix={r["prefix"]}, Root={r["root"]}, Suffix={r["suffix"]}')
