import math
from collections import Counter

text = 'the cat sat on the mat the cat is fat'
words = text.split()

freq = Counter(words)
total = len(words)
prob = {w: freq[w]/total for w in freq}

entropy = -sum(p * math.log2(p) for p in prob.values())
print(f'Entropy: {entropy:.4f} bits')

vocab_size = len(prob)
q = 1 / vocab_size
cross_entropy = -sum(p * math.log2(q) for p in prob.values())
print(f'Cross-Entropy: {cross_entropy:.4f} bits')

perplexity = 2 ** cross_entropy
print(f'Perplexity: {perplexity:.4f}')
