import re

def pos_tag(word):
    w = word.lower()
    if w in ['is','are','was','were','be','been','am']: return 'VB'
    if w in ['the','a','an']:                           return 'DT'
    if w in ['in','on','at','by','of','to','with']:    return 'PP'
    if w in ['and','or','but']:                        return 'CC'
    if re.search(r'ing$', w):                          return 'VBG'
    if re.search(r'ed$', w):                           return 'VBD'
    if re.search(r'ly$', w):                           return 'RB'
    if re.search(r'(tion|ness|ment)$', w):             return 'NN'
    if re.search(r'(ful|ous|ive|al)$', w):             return 'JJ'
    if re.search(r'^[A-Z]', word):                     return 'NNP'
    return 'NN'

text = 'John is running fast. The dog barked loudly. She loves reading books!'
sentences = re.split(r'[.!?]', text)
sentences = [s.strip() for s in sentences if s.strip()]

for i, sent in enumerate(sentences, 1):
    tokens = sent.split()
    tagged = [(w, pos_tag(w)) for w in tokens]
    print(f'Sentence {i}: {tagged}')
