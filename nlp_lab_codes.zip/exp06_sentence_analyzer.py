import re

COORD_CONJ = ['and', 'but', 'or', 'nor', 'so', 'yet', 'for']
SUB_CONJ   = ['because', 'although', 'if', 'when', 'while',
              'since', 'unless', 'after', 'before', 'as']
WH_WORDS   = ['what', 'where', 'when', 'who', 'why', 'how', 'which']
AUX_VERBS  = ['is', 'are', 'was', 'were', 'do', 'does', 'did',
              'can', 'will', 'would', 'should', 'could']

def classify(sentence):
    s    = sentence.strip()
    low  = s.lower()
    words = low.split()

    if s.endswith('?'):
        return 'Interrogative'
    if words and words[0] in WH_WORDS + AUX_VERBS:
        return 'Interrogative'

    for c in SUB_CONJ:
        if f' {c} ' in low:
            return f'Complex (subordinating: "{c}")'

    for c in COORD_CONJ:
        if f' {c} ' in low:
            return f'Compound (coordinating: "{c}")'

    return 'Simple Declarative'

sentences = [
    'The sun rises in the east.',
    'Where are you going?',
    'She stayed home because it was raining.',
    'I like tea but she prefers coffee.',
    'Did you finish the assignment?'
]
for s in sentences:
    print(f'{classify(s)}: {s}')
