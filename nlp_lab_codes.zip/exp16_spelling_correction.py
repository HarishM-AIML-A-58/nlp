from collections import Counter

def edit_distance(s1, s2):
    m, n = len(s1), len(s2)
    dp   = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m+1): dp[i][0] = i
    for j in range(n+1): dp[0][j] = j
    for i in range(1,m+1):
        for j in range(1,n+1):
            if s1[i-1]==s2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(dp[i-1][j],
                                   dp[i][j-1],
                                   dp[i-1][j-1])
    return dp[m][n]

corpus = 'the cat sat on the mat a cat is fat the dog ran fast'
vocab  = set(corpus.split())
words  = corpus.split()
bigrams = Counter(zip(words, words[1:]))
uni     = Counter(words)

def correct(word, prev=None):
    candidates = [(v, edit_distance(word, v)) for v in vocab]
    candidates = [(v,d) for v,d in candidates if d <= 2]
    candidates.sort(key=lambda x: x[1])
    if not candidates: return word
    if prev:
        def score(v):
            ed  = edit_distance(word, v)
            bg  = bigrams.get((prev,v), 0) + 1
            return ed - 0.5 * (bg / (uni[prev]+len(vocab)))
        candidates.sort(key=lambda x: score(x[0]))
    return candidates[0][0]

pairs = [('cat','car'), ('kitten','sitting'), ('mat','bat')]
for a,b in pairs:
    print(f'edit_distance("{a}","{b}") = {edit_distance(a,b)}')

print()
typos = [('kat', None), ('cta', 'the'), ('mta', 'the')]
for word, prev in typos:
    print(f'correct("{word}", prev="{prev}") -> {correct(word, prev)}')
