from textblob import TextBlob

text = "I havv goood speling"

blob = TextBlob(text)

print(blob.correct())
