import nltk
from nltk.corpus import treebank
from nltk.tag import hmm

nltk.download('treebank')

train_data = treebank.tagged_sents()[:3000]

tagger = hmm.HiddenMarkovModelTrainer().train(train_data)

print(tagger.tag("NLP is useful".split()))
