NLP Lab Programs

Programs Included:
1. Morphological Analyzer
2. Basic NLP Pipeline
3. Named Entity Recognition
4. N-Gram Models
5. Laplace Smoothing
6. Spelling Correction
7. TF-IDF and Cosine Similarity
8. Word2Vec
9. HMM POS Tagging

Install Dependencies:
pip install -r requirements.txt

For spaCy model:
python -m spacy download en_core_web_sm
