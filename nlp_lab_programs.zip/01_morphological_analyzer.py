import spacy

nlp = spacy.load("en_core_web_sm")

text = "How are you? I am fine. She went to college and completed her assignment."

doc = nlp(text)

print("Sentence Segmentation:")
for sent in doc.sents:
    print(sent.text)

print("\nMorphological Analysis:")
for token in doc:
    print(f"Word: {token.text}")
    print(f"Lemma: {token.lemma_}")
    print(f"POS: {token.pos_}")
    print(f"Morphology: {token.morph}")
    print("----------------")
