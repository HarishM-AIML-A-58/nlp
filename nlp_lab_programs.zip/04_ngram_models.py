import nltk
from nltk.corpus import brown
from nltk.util import ngrams

nltk.download('brown')

words = brown.words()

unigrams = list(ngrams(words, 1))
bigrams = list(ngrams(words, 2))
trigrams = list(ngrams(words, 3))

print("Unigrams:", unigrams[:5])
print("Bigrams:", bigrams[:5])
print("Trigrams:", trigrams[:5])
