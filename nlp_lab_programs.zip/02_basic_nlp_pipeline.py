import spacy

nlp = spacy.load("en_core_web_sm")

text = "Natural Language Processing is interesting. Students are learning NLP."

doc = nlp(text)

print("Sentence Segmentation:")
for sent in doc.sents:
    print(sent.text)

print("\nTokenization and POS Tagging:")
for token in doc:
    print(token.text, token.pos_)
