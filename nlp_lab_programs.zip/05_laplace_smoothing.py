from collections import Counter
from nltk.util import bigrams

text = "natural language processing is fun"
words = text.split()

bigram_list = list(bigrams(words))
count = Counter(bigram_list)

vocab_size = len(set(words))

for bg in count:
    probability = (count[bg] + 1) / (len(words) + vocab_size)
    print(bg, probability)
