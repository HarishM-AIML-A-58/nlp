from gensim.models import Word2Vec

sentences = [
    ["nlp", "is", "interesting"],
    ["machine", "learning", "is", "powerful"]
]

model = Word2Vec(sentences, vector_size=50, window=3, min_count=1)

print(model.wv['nlp'])
