from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

corpus = [
    "NLP is interesting",
    "Machine learning is important",
    "NLP and ML are related"
]

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(corpus)

similarity = cosine_similarity(X)

print(similarity)
